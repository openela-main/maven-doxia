Here is some code:

    mvn clean package
