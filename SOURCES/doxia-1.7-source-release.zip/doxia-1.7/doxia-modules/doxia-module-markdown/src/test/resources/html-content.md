
<div>
<p><b>Example</b> is a <b>test</b> of mixing html and markdown

</p>
</div>

---

Heading
=======

Some text

<table>
<tr><th>column</th></tr>
<tr><td>data</td></tr>
</table>